# Combined: DTS's Harry-box fix (if not already uploaded) + Triangling's new Harry box

## Important — check this first
Your last message described DTS still showing Harry alongside the other
3 characters. When I checked the actual live site just now, that fix
(excluding Harry from DTS's choices, adding his separate box) was
confirmed NOT yet uploaded — the previous zip is likely still sitting
unopened. This file includes that fix again, combined with the new work
below, so uploading this one covers both.

## 1. DTS — Harry excluded from character choices, own distinct box
(Same as before, included here again in case the last zip wasn't
uploaded yet.)

## 2. Triangling — matching Harry box added
Same visual pattern as DTS: bordered box, bigger image (80px), permanent
label "You're always speaking to Harry." Placed above the character
choices, exactly like DTS.

**One difference from DTS, on purpose:** Triangling's Harry box is NOT
clickable and has no "tap to replay" sub-text — Triangling never had a
Harry-modeling/replay feature to begin with, so I only added the visual
"who you're addressing" indicator, not functionality that wasn't asked
for here. Let me know if you actually want the same tap-to-replay
behavior added to Triangling too.

## File
- `index.html` only. game3.js untouched.

## Verified
- Diffed against the actual current live file — confirmed the full set
  of changes is exactly what's described above, nothing unexpected
